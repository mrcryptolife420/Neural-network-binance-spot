# Restore Instructions

Run restore-preview before any restore.

Live trading enabled: false
